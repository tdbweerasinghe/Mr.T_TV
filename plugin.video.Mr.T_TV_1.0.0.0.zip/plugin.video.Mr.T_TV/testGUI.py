import xbmcaddon
import xbmcgui
import xbmcplugin
 
def GUIEditExportName(name):
    exit = True
    while (exit):
          kb = xbmc.Keyboard('default', 'heading', True)
          kb.setDefault(name)
          kb.setHeading(__language__(33223))
          kb.setHiddenInput(False)
          kb.doModal()
          if (kb.isConfirmed()):
              name_confirmed  = kb.getText()
              name_correct = name_confirmed.count(' ')
              if (name_correct):
                 GUIInfo(2,__language__(33224))
              else:
                   name = name_confirmed
                   exit = False
          else:
              GUIInfo(2,__language__(33225))
    return(name)

"""GUIEditExportName("THARINDU")"""