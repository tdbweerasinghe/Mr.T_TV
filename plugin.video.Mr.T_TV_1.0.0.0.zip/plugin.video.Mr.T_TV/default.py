import sys
import urllib
import urlparse        
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')
"""Get the add-on""" 
my_addon    = xbmcaddon.Addon('plugin.video.Mr.T_TV')
"""Get the add-on settings"""
my_setting  = my_addon.getSetting('my_setting')
"""Get the parent control pwd"""
my_pwd = my_addon.getSetting('my_password')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

if mode is None:      
    url = build_url({'mode': 'Category-1', 'foldername': 'Category-1'})
    li = xbmcgui.ListItem('Adult Movies', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    url = build_url({'mode': 'Category-2', 'foldername': 'Category-2'})
    li = xbmcgui.ListItem('Fashion', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)   

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'Category-1':
    """Checking the settings on Parental Control:"""
    if (my_setting == 'true'):
        foldername = args['foldername'][0]
        url = 'http://www.seebo.com.au/calvista/videos/ThePrivateGladiator_c1.mkv'
        li = xbmcgui.ListItem(foldername + ' Video', iconImage='DefaultVideo.png')        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)        
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        dialog = xbmcgui.Dialog()
        """ This doesn't work in XBMC 12.3"""
        """password = dialog.input('Enter Password:', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)"""
        password = dialog.numeric(0, 'Numeric Password:')        
        """dialog.ok(hashValue)"""
        if (password == my_pwd):
            foldername = args['foldername'][0]
            url = 'http://www.seebo.com.au/calvista/videos/ThePrivateGladiator_c1.mkv'
            li = xbmcgui.ListItem(foldername + ' Video', iconImage='DefaultVideo.png')        
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)        
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            dialog.ok('Adult Content', 'Wrong Password!!!')           
    
elif mode[0] == 'Category-2':
    foldername = args['foldername'][0]
    url = 'http://www.seebo.com.au/calvista/videos/FashionPolice.mp4'
    li = xbmcgui.ListItem(foldername + ' Video', iconImage='DefaultVideo.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    xbmcplugin.endOfDirectory(addon_handle)  
